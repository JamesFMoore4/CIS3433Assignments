﻿namespace Ass3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            menuStrip1 = new MenuStrip();
            cityToolStripMenuItem = new ToolStripMenuItem();
            jacksonvilleToolStripMenuItem = new ToolStripMenuItem();
            miamiToolStripMenuItem = new ToolStripMenuItem();
            tampaToolStripMenuItem = new ToolStripMenuItem();
            orlandoToolStripMenuItem = new ToolStripMenuItem();
            directionToolStripMenuItem = new ToolStripMenuItem();
            nEToolStripMenuItem1 = new ToolStripMenuItem();
            sEToolStripMenuItem = new ToolStripMenuItem();
            nWToolStripMenuItem = new ToolStripMenuItem();
            sWToolStripMenuItem = new ToolStripMenuItem();
            Picture = new PictureBox();
            timer1 = new System.Windows.Forms.Timer(components);
            contextMenuStrip1 = new ContextMenuStrip(components);
            jacksonvilleToolStripMenuItem1 = new ToolStripMenuItem();
            miamiToolStripMenuItem1 = new ToolStripMenuItem();
            tampaToolStripMenuItem1 = new ToolStripMenuItem();
            orlandoToolStripMenuItem1 = new ToolStripMenuItem();
            toolStripSeparator1 = new ToolStripSeparator();
            nEToolStripMenuItem = new ToolStripMenuItem();
            sEToolStripMenuItem1 = new ToolStripMenuItem();
            nWToolStripMenuItem1 = new ToolStripMenuItem();
            sWToolStripMenuItem1 = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Picture).BeginInit();
            contextMenuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { cityToolStripMenuItem, directionToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // cityToolStripMenuItem
            // 
            cityToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { jacksonvilleToolStripMenuItem, miamiToolStripMenuItem, tampaToolStripMenuItem, orlandoToolStripMenuItem });
            cityToolStripMenuItem.Name = "cityToolStripMenuItem";
            cityToolStripMenuItem.Size = new Size(40, 20);
            cityToolStripMenuItem.Text = "City";
            // 
            // jacksonvilleToolStripMenuItem
            // 
            jacksonvilleToolStripMenuItem.Name = "jacksonvilleToolStripMenuItem";
            jacksonvilleToolStripMenuItem.Size = new Size(136, 22);
            jacksonvilleToolStripMenuItem.Text = "Jacksonville";
            jacksonvilleToolStripMenuItem.Click += jacksonvilleToolStripMenuItem_Click;
            // 
            // miamiToolStripMenuItem
            // 
            miamiToolStripMenuItem.Name = "miamiToolStripMenuItem";
            miamiToolStripMenuItem.Size = new Size(136, 22);
            miamiToolStripMenuItem.Text = "Miami";
            miamiToolStripMenuItem.Click += miamiToolStripMenuItem_Click;
            // 
            // tampaToolStripMenuItem
            // 
            tampaToolStripMenuItem.Name = "tampaToolStripMenuItem";
            tampaToolStripMenuItem.Size = new Size(136, 22);
            tampaToolStripMenuItem.Text = "Tampa";
            tampaToolStripMenuItem.Click += tampaToolStripMenuItem_Click;
            // 
            // orlandoToolStripMenuItem
            // 
            orlandoToolStripMenuItem.Name = "orlandoToolStripMenuItem";
            orlandoToolStripMenuItem.Size = new Size(136, 22);
            orlandoToolStripMenuItem.Text = "Orlando";
            orlandoToolStripMenuItem.Click += orlandoToolStripMenuItem_Click;
            // 
            // directionToolStripMenuItem
            // 
            directionToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { nEToolStripMenuItem1, sEToolStripMenuItem, nWToolStripMenuItem, sWToolStripMenuItem });
            directionToolStripMenuItem.Name = "directionToolStripMenuItem";
            directionToolStripMenuItem.Size = new Size(67, 20);
            directionToolStripMenuItem.Text = "Direction";
            // 
            // nEToolStripMenuItem1
            // 
            nEToolStripMenuItem1.Name = "nEToolStripMenuItem1";
            nEToolStripMenuItem1.Size = new Size(94, 22);
            nEToolStripMenuItem1.Text = "NE";
            nEToolStripMenuItem1.Click += nEToolStripMenuItem1_Click;
            // 
            // sEToolStripMenuItem
            // 
            sEToolStripMenuItem.Name = "sEToolStripMenuItem";
            sEToolStripMenuItem.Size = new Size(94, 22);
            sEToolStripMenuItem.Text = "SE";
            sEToolStripMenuItem.Click += sEToolStripMenuItem_Click;
            // 
            // nWToolStripMenuItem
            // 
            nWToolStripMenuItem.Name = "nWToolStripMenuItem";
            nWToolStripMenuItem.Size = new Size(94, 22);
            nWToolStripMenuItem.Text = "NW";
            nWToolStripMenuItem.Click += nWToolStripMenuItem_Click;
            // 
            // sWToolStripMenuItem
            // 
            sWToolStripMenuItem.Name = "sWToolStripMenuItem";
            sWToolStripMenuItem.Size = new Size(94, 22);
            sWToolStripMenuItem.Text = "SW";
            sWToolStripMenuItem.Click += sWToolStripMenuItem_Click;
            // 
            // Picture
            // 
            Picture.Image = Properties.Resources.Jacksonville;
            Picture.Location = new Point(317, 148);
            Picture.Name = "Picture";
            Picture.Size = new Size(150, 150);
            Picture.SizeMode = PictureBoxSizeMode.StretchImage;
            Picture.TabIndex = 1;
            Picture.TabStop = false;
            Picture.Visible = false;
            Picture.MouseClick += Picture_MouseClick;
            // 
            // timer1
            // 
            timer1.Interval = 250;
            timer1.Tick += timer1_Tick;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { jacksonvilleToolStripMenuItem1, miamiToolStripMenuItem1, tampaToolStripMenuItem1, orlandoToolStripMenuItem1, toolStripSeparator1, nEToolStripMenuItem, sEToolStripMenuItem1, nWToolStripMenuItem1, sWToolStripMenuItem1 });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(137, 186);
            // 
            // jacksonvilleToolStripMenuItem1
            // 
            jacksonvilleToolStripMenuItem1.Name = "jacksonvilleToolStripMenuItem1";
            jacksonvilleToolStripMenuItem1.Size = new Size(136, 22);
            jacksonvilleToolStripMenuItem1.Text = "Jacksonville";
            jacksonvilleToolStripMenuItem1.Click += jacksonvilleToolStripMenuItem_Click;
            // 
            // miamiToolStripMenuItem1
            // 
            miamiToolStripMenuItem1.Name = "miamiToolStripMenuItem1";
            miamiToolStripMenuItem1.Size = new Size(136, 22);
            miamiToolStripMenuItem1.Text = "Miami";
            miamiToolStripMenuItem1.Click += miamiToolStripMenuItem_Click;
            // 
            // tampaToolStripMenuItem1
            // 
            tampaToolStripMenuItem1.Name = "tampaToolStripMenuItem1";
            tampaToolStripMenuItem1.Size = new Size(136, 22);
            tampaToolStripMenuItem1.Text = "Tampa";
            tampaToolStripMenuItem1.Click += tampaToolStripMenuItem_Click;
            // 
            // orlandoToolStripMenuItem1
            // 
            orlandoToolStripMenuItem1.Name = "orlandoToolStripMenuItem1";
            orlandoToolStripMenuItem1.Size = new Size(136, 22);
            orlandoToolStripMenuItem1.Text = "Orlando";
            orlandoToolStripMenuItem1.Click += orlandoToolStripMenuItem_Click;
            // 
            // toolStripSeparator1
            // 
            toolStripSeparator1.Name = "toolStripSeparator1";
            toolStripSeparator1.Size = new Size(133, 6);
            // 
            // nEToolStripMenuItem
            // 
            nEToolStripMenuItem.Name = "nEToolStripMenuItem";
            nEToolStripMenuItem.Size = new Size(136, 22);
            nEToolStripMenuItem.Text = "NE";
            nEToolStripMenuItem.Click += nEToolStripMenuItem1_Click;
            // 
            // sEToolStripMenuItem1
            // 
            sEToolStripMenuItem1.Name = "sEToolStripMenuItem1";
            sEToolStripMenuItem1.Size = new Size(136, 22);
            sEToolStripMenuItem1.Text = "SE";
            sEToolStripMenuItem1.Click += sEToolStripMenuItem_Click;
            // 
            // nWToolStripMenuItem1
            // 
            nWToolStripMenuItem1.Name = "nWToolStripMenuItem1";
            nWToolStripMenuItem1.Size = new Size(136, 22);
            nWToolStripMenuItem1.Text = "NW";
            nWToolStripMenuItem1.Click += nWToolStripMenuItem_Click;
            // 
            // sWToolStripMenuItem1
            // 
            sWToolStripMenuItem1.Name = "sWToolStripMenuItem1";
            sWToolStripMenuItem1.Size = new Size(136, 22);
            sWToolStripMenuItem1.Text = "SW";
            sWToolStripMenuItem1.Click += sWToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Picture);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Cities";
            Click += Form1_Click;
            DoubleClick += Form1_DoubleClick;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)Picture).EndInit();
            contextMenuStrip1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem cityToolStripMenuItem;
        private ToolStripMenuItem jacksonvilleToolStripMenuItem;
        private ToolStripMenuItem miamiToolStripMenuItem;
        private ToolStripMenuItem tampaToolStripMenuItem;
        private ToolStripMenuItem orlandoToolStripMenuItem;
        private ToolStripMenuItem directionToolStripMenuItem;
        private ToolStripMenuItem nEToolStripMenuItem1;
        private ToolStripMenuItem sEToolStripMenuItem;
        private ToolStripMenuItem nWToolStripMenuItem;
        private ToolStripMenuItem sWToolStripMenuItem;
        private PictureBox Picture;
        private System.Windows.Forms.Timer timer1;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem jacksonvilleToolStripMenuItem1;
        private ToolStripMenuItem miamiToolStripMenuItem1;
        private ToolStripMenuItem tampaToolStripMenuItem1;
        private ToolStripMenuItem orlandoToolStripMenuItem1;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem nEToolStripMenuItem;
        private ToolStripMenuItem sEToolStripMenuItem1;
        private ToolStripMenuItem nWToolStripMenuItem1;
        private ToolStripMenuItem sWToolStripMenuItem1;
    }
}

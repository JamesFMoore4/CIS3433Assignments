using System.ComponentModel.Design;

namespace Ass3
{
    public partial class Form1 : Form
    {

        int xDir = 0, yDir = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            if (Picture.Visible)
                timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int nextTop = Picture.Top + yDir, nextLeft = Picture.Left + xDir;

            if (nextTop < 0 || nextTop > this.ClientSize.Height - Picture.Height || nextLeft < 0 || nextLeft > this.ClientSize.Width - Picture.Width)
                timer1.Stop();
            else
            {
                Picture.Top += yDir;
                Picture.Left += xDir;
            }
        }

        private void Form1_DoubleClick(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void nEToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            xDir = 8;
            yDir = -5;
        }

        private void sEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            xDir = 8;
            yDir = 5;
        }

        private void nWToolStripMenuItem_Click(object sender, EventArgs e)
        {
            xDir = -8;
            yDir = -5;
        }

        private void sWToolStripMenuItem_Click(object sender, EventArgs e)
        {
            xDir = -8;
            yDir = 5;
        }

        private void jacksonvilleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Picture.Visible = true;
            Picture.Image = Properties.Resources.Jacksonville;
        }

        private void miamiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Picture.Visible = true;
            Picture.Image = Properties.Resources.Miami;
        }

        private void tampaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Picture.Visible = true;
            Picture.Image = Properties.Resources.Tampa;
        }

        private void orlandoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Picture.Visible = true;
            Picture.Image = Properties.Resources.Orlando;
        }

        private void Picture_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
                contextMenuStrip1.Show(Picture, 0, Picture.Height);

        }
    }
}

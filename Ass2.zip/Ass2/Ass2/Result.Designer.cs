﻿namespace Ass2
{
    partial class Result
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            label1 = new Label();
            label2 = new Label();
            label4 = new Label();
            label5 = new Label();
            TotalMissedAmount = new Label();
            TotalMatchedAmount = new Label();
            CurrentBalanceAmount = new Label();
            TotalMissedNum = new Label();
            TotalMatchedNum = new Label();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F);
            label3.Location = new Point(26, 41);
            label3.Name = "label3";
            label3.Size = new Size(108, 21);
            label3.TabIndex = 6;
            label3.Text = "Initial balance:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(26, 76);
            label1.Name = "label1";
            label1.Size = new Size(98, 21);
            label1.TabIndex = 7;
            label1.Text = "Total missed:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F);
            label2.Location = new Point(26, 112);
            label2.Name = "label2";
            label2.Size = new Size(109, 21);
            label2.TabIndex = 8;
            label2.Text = "Total matched:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F);
            label4.Location = new Point(26, 147);
            label4.Name = "label4";
            label4.Size = new Size(123, 21);
            label4.TabIndex = 9;
            label4.Text = "Current balance:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(328, 42);
            label5.Name = "label5";
            label5.Size = new Size(28, 15);
            label5.TabIndex = 10;
            label5.Text = " $10";
            // 
            // TotalMissedAmount
            // 
            TotalMissedAmount.AutoSize = true;
            TotalMissedAmount.Location = new Point(328, 82);
            TotalMissedAmount.Name = "TotalMissedAmount";
            TotalMissedAmount.Size = new Size(19, 15);
            TotalMissedAmount.TabIndex = 11;
            TotalMissedAmount.Text = "$0";
            // 
            // TotalMatchedAmount
            // 
            TotalMatchedAmount.AutoSize = true;
            TotalMatchedAmount.Location = new Point(328, 117);
            TotalMatchedAmount.Name = "TotalMatchedAmount";
            TotalMatchedAmount.Size = new Size(19, 15);
            TotalMatchedAmount.TabIndex = 12;
            TotalMatchedAmount.Text = "$0";
            // 
            // CurrentBalanceAmount
            // 
            CurrentBalanceAmount.AutoSize = true;
            CurrentBalanceAmount.Location = new Point(328, 152);
            CurrentBalanceAmount.Name = "CurrentBalanceAmount";
            CurrentBalanceAmount.Size = new Size(19, 15);
            CurrentBalanceAmount.TabIndex = 13;
            CurrentBalanceAmount.Text = "$0";
            // 
            // TotalMissedNum
            // 
            TotalMissedNum.AutoSize = true;
            TotalMissedNum.Location = new Point(219, 82);
            TotalMissedNum.Name = "TotalMissedNum";
            TotalMissedNum.Size = new Size(13, 15);
            TotalMissedNum.TabIndex = 14;
            TotalMissedNum.Text = "0";
            // 
            // TotalMatchedNum
            // 
            TotalMatchedNum.AutoSize = true;
            TotalMatchedNum.Location = new Point(219, 118);
            TotalMatchedNum.Name = "TotalMatchedNum";
            TotalMatchedNum.Size = new Size(13, 15);
            TotalMatchedNum.TabIndex = 15;
            TotalMatchedNum.Text = "0";
            // 
            // Result
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(400, 222);
            Controls.Add(TotalMatchedNum);
            Controls.Add(TotalMissedNum);
            Controls.Add(CurrentBalanceAmount);
            Controls.Add(TotalMatchedAmount);
            Controls.Add(TotalMissedAmount);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(label3);
            Name = "Result";
            Text = "Result";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private Label label1;
        private Label label2;
        private Label label4;
        private Label label5;
        private Label TotalMissedAmount;
        private Label TotalMatchedAmount;
        private Label CurrentBalanceAmount;
        private Label TotalMissedNum;
        private Label TotalMatchedNum;
    }
}
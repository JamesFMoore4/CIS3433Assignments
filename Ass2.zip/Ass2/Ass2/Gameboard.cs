﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ass2
{
    public partial class Gameboard : Form
    {

        int balance = 10, missed = 0, matched = 0, guess, randvalue;
        Random random = new Random();

        public Gameboard()
        {
            InitializeComponent();
        }

        private void SummaryButton_Click(object sender, EventArgs e)
        {
            Result results = new Result(balance, missed, matched);
            results.Show();
        }

        private void UserGuess_TextChanged(object sender, EventArgs e)
        {
            Enter.Enabled = true;
            BankerNumber.Text = "?";
        }

        private void Enter_Click(object sender, EventArgs e)
        {
            try
            {
                guess = Int32.Parse(UserGuess.Text);
                Open.Enabled = true;
            }
            catch (FormatException)
            {
                UserGuess.Text = "";
            }
        }

        private void Open_Click(object sender, EventArgs e)
        {
            randvalue = random.Next(1, 6);
            BankerNumber.Text = randvalue.ToString();

            if (guess != randvalue)
            {
                balance--;
                missed++;
            }
            else
            {
                balance += 5;
                matched++;
            }

            CurrentBalance.Text = "$" + balance.ToString();

            if (balance == 0)
            {
                MessageBox.Show("Sorry, you have zero balance.", "Game over");
                this.Close();
            }
            else
            {
                Open.Enabled = false;
                Enter.Enabled = false;
            }

        }
    }
}

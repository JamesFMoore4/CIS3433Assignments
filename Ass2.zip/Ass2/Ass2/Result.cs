﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ass2
{
    public partial class Result : Form
    {

        public Result(int balance, int missed, int matched)
        {
            InitializeComponent();

            TotalMissedNum.Text = missed.ToString();
            if (missed > 0)
            {
                TotalMissedAmount.Text = "-$" + missed.ToString();
            }
            else
            {
                TotalMissedAmount.Text = " $0";
            }
            TotalMatchedNum.Text = matched.ToString();
            TotalMatchedAmount.Text = " $" + (5 * matched).ToString();
            CurrentBalanceAmount.Text = " $" + balance.ToString();

        }
    }
}

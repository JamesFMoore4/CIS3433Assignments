﻿namespace Ass2
{
    partial class Gameboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            Enter = new Button();
            Open = new Button();
            SummaryButton = new Button();
            label3 = new Label();
            label4 = new Label();
            UserGuess = new TextBox();
            label5 = new Label();
            BankerNumber = new Label();
            label6 = new Label();
            CurrentBalance = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.Blue;
            label1.Location = new Point(47, 40);
            label1.Name = "label1";
            label1.Size = new Size(261, 15);
            label1.TabIndex = 0;
            label1.Text = "*Each guess costs $1 if it doesn't match banker's";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.Blue;
            label2.Location = new Point(47, 55);
            label2.Name = "label2";
            label2.Size = new Size(237, 15);
            label2.TabIndex = 1;
            label2.Text = "*If your guess matches banker's, you win $5";
            // 
            // Enter
            // 
            Enter.Enabled = false;
            Enter.Location = new Point(311, 125);
            Enter.Name = "Enter";
            Enter.Size = new Size(87, 32);
            Enter.TabIndex = 2;
            Enter.Text = "Enter";
            Enter.UseVisualStyleBackColor = true;
            Enter.Click += Enter_Click;
            // 
            // Open
            // 
            Open.Enabled = false;
            Open.Location = new Point(311, 194);
            Open.Name = "Open";
            Open.Size = new Size(87, 32);
            Open.TabIndex = 3;
            Open.Text = "Open";
            Open.UseVisualStyleBackColor = true;
            Open.Click += Open_Click;
            // 
            // SummaryButton
            // 
            SummaryButton.Location = new Point(311, 264);
            SummaryButton.Name = "SummaryButton";
            SummaryButton.Size = new Size(87, 32);
            SummaryButton.TabIndex = 4;
            SummaryButton.Text = "Summary";
            SummaryButton.UseVisualStyleBackColor = true;
            SummaryButton.Click += SummaryButton_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F);
            label3.Location = new Point(47, 120);
            label3.Name = "label3";
            label3.Size = new Size(129, 21);
            label3.TabIndex = 5;
            label3.Text = "Enter your guess:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F);
            label4.Location = new Point(47, 141);
            label4.Name = "label4";
            label4.Size = new Size(57, 21);
            label4.TabIndex = 6;
            label4.Text = "(1 ~ 5)";
            // 
            // UserGuess
            // 
            UserGuess.BackColor = Color.FromArgb(128, 255, 255);
            UserGuess.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            UserGuess.ForeColor = Color.Blue;
            UserGuess.Location = new Point(182, 122);
            UserGuess.Name = "UserGuess";
            UserGuess.Size = new Size(59, 35);
            UserGuess.TabIndex = 7;
            UserGuess.TextChanged += UserGuess_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F);
            label5.Location = new Point(47, 198);
            label5.Name = "label5";
            label5.Size = new Size(131, 21);
            label5.TabIndex = 8;
            label5.Text = "Banker's number:";
            // 
            // BankerNumber
            // 
            BankerNumber.AutoSize = true;
            BankerNumber.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            BankerNumber.ForeColor = Color.Fuchsia;
            BankerNumber.Location = new Point(192, 175);
            BankerNumber.Name = "BankerNumber";
            BankerNumber.Size = new Size(49, 65);
            BankerNumber.TabIndex = 9;
            BankerNumber.Text = "?";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F);
            label6.Location = new Point(45, 264);
            label6.Name = "label6";
            label6.Size = new Size(102, 21);
            label6.TabIndex = 10;
            label6.Text = "Your balance:";
            // 
            // CurrentBalance
            // 
            CurrentBalance.AutoSize = true;
            CurrentBalance.Font = new Font("Segoe UI", 24F);
            CurrentBalance.ForeColor = Color.Black;
            CurrentBalance.Location = new Point(182, 253);
            CurrentBalance.Name = "CurrentBalance";
            CurrentBalance.Size = new Size(71, 45);
            CurrentBalance.TabIndex = 11;
            CurrentBalance.Text = "$10";
            // 
            // Gameboard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(435, 352);
            Controls.Add(CurrentBalance);
            Controls.Add(label6);
            Controls.Add(BankerNumber);
            Controls.Add(label5);
            Controls.Add(UserGuess);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(SummaryButton);
            Controls.Add(Open);
            Controls.Add(Enter);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Gameboard";
            Text = "Game Board";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Button Enter;
        private Button Open;
        private Button SummaryButton;
        private Label label3;
        private Label label4;
        private TextBox UserGuess;
        private Label label5;
        private Label BankerNumber;
        private Label label6;
        private Label CurrentBalance;
    }
}
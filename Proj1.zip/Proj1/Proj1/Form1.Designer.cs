﻿namespace Proj1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            RangeLabel = new Label();
            RangeTextBox = new TextBox();
            EnterButton = new Button();
            NumberDisplay = new Label();
            SlowButton = new RadioButton();
            FastButton = new RadioButton();
            SummaryDisplay = new Label();
            NumberLabel = new Label();
            Timer = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // RangeLabel
            // 
            RangeLabel.AutoSize = true;
            RangeLabel.Location = new Point(28, 57);
            RangeLabel.Name = "RangeLabel";
            RangeLabel.Size = new Size(165, 15);
            RangeLabel.TabIndex = 0;
            RangeLabel.Text = "Enter a number to set a range:";
            // 
            // RangeTextBox
            // 
            RangeTextBox.Location = new Point(199, 54);
            RangeTextBox.Name = "RangeTextBox";
            RangeTextBox.Size = new Size(72, 23);
            RangeTextBox.TabIndex = 1;
            // 
            // EnterButton
            // 
            EnterButton.Location = new Point(277, 54);
            EnterButton.Name = "EnterButton";
            EnterButton.Size = new Size(59, 23);
            EnterButton.TabIndex = 2;
            EnterButton.Text = "Enter";
            EnterButton.UseVisualStyleBackColor = true;
            EnterButton.Click += EnterButton_Click;
            // 
            // NumberDisplay
            // 
            NumberDisplay.AutoSize = true;
            NumberDisplay.Font = new Font("Segoe UI", 69F, FontStyle.Bold, GraphicsUnit.Point, 0);
            NumberDisplay.ForeColor = Color.Blue;
            NumberDisplay.Location = new Point(54, 98);
            NumberDisplay.Name = "NumberDisplay";
            NumberDisplay.Size = new Size(92, 123);
            NumberDisplay.TabIndex = 3;
            NumberDisplay.Text = "?";
            NumberDisplay.Click += NumberDisplay_Click;
            // 
            // SlowButton
            // 
            SlowButton.AutoSize = true;
            SlowButton.Location = new Point(251, 146);
            SlowButton.Name = "SlowButton";
            SlowButton.Size = new Size(50, 19);
            SlowButton.TabIndex = 4;
            SlowButton.TabStop = true;
            SlowButton.Text = "Slow";
            SlowButton.UseVisualStyleBackColor = true;
            SlowButton.Click += SlowButton_Click;
            // 
            // FastButton
            // 
            FastButton.AutoSize = true;
            FastButton.Location = new Point(251, 171);
            FastButton.Name = "FastButton";
            FastButton.Size = new Size(46, 19);
            FastButton.TabIndex = 5;
            FastButton.TabStop = true;
            FastButton.Text = "Fast";
            FastButton.UseVisualStyleBackColor = true;
            FastButton.Click += FastButton_Click;
            // 
            // SummaryDisplay
            // 
            SummaryDisplay.AutoSize = true;
            SummaryDisplay.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            SummaryDisplay.ForeColor = Color.Fuchsia;
            SummaryDisplay.Location = new Point(28, 270);
            SummaryDisplay.Name = "SummaryDisplay";
            SummaryDisplay.Size = new Size(28, 21);
            SummaryDisplay.TabIndex = 6;
            SummaryDisplay.Text = "---";
            // 
            // NumberLabel
            // 
            NumberLabel.AutoSize = true;
            NumberLabel.Location = new Point(28, 242);
            NumberLabel.Name = "NumberLabel";
            NumberLabel.Size = new Size(118, 15);
            NumberLabel.TabIndex = 7;
            NumberLabel.Text = "15 numbers selected:";
            // 
            // Timer
            // 
            Timer.Tick += Timer_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(580, 338);
            Controls.Add(NumberLabel);
            Controls.Add(SummaryDisplay);
            Controls.Add(FastButton);
            Controls.Add(SlowButton);
            Controls.Add(NumberDisplay);
            Controls.Add(EnterButton);
            Controls.Add(RangeTextBox);
            Controls.Add(RangeLabel);
            Name = "Form1";
            Text = "Form1";
            Click += Form1_Click;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label RangeLabel;
        private TextBox RangeTextBox;
        private Button EnterButton;
        private Label NumberDisplay;
        private RadioButton SlowButton;
        private RadioButton FastButton;
        private Label SummaryDisplay;
        private Label NumberLabel;
        private System.Windows.Forms.Timer Timer;
    }
}

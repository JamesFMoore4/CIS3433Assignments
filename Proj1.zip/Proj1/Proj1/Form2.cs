﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj1
{
    public partial class Form2 : Form
    {

        int zero = 0, neg = 0, pos = 0;
        List<int> nums = new List<int>();

        public Form2(List<int> nums)
        {
            InitializeComponent();
            this.nums = nums;
            displaySummary();
        }

        private void displaySummary()
        {

            for (int i = 0; i < nums.Count; i++)
            {
                if (i == 0)
                {
                    SummaryDisplay.Text = nums[i].ToString();
                }
                else
                {
                    SummaryDisplay.Text += ", " + nums[i].ToString();
                }

                if (nums[i] == 0)
                {
                    zero++;
                }
                else if (nums[i] < 0)
                {
                    neg++;
                }
                else
                {
                    pos++;
                }
            }

            PosNum.Text = pos.ToString();
            ZeroNum.Text = zero.ToString();
            NegNum.Text = neg.ToString();
        }
    }
}

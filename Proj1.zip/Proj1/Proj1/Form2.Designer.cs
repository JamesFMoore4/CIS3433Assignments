﻿namespace Proj1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            SummaryDisplay = new Label();
            NumberLabel = new Label();
            TotalPositive = new Label();
            TotalZero = new Label();
            TotalNegative = new Label();
            PosNum = new Label();
            ZeroNum = new Label();
            NegNum = new Label();
            SuspendLayout();
            // 
            // SummaryDisplay
            // 
            SummaryDisplay.AutoSize = true;
            SummaryDisplay.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            SummaryDisplay.ForeColor = Color.Fuchsia;
            SummaryDisplay.Location = new Point(12, 60);
            SummaryDisplay.Name = "SummaryDisplay";
            SummaryDisplay.Size = new Size(28, 21);
            SummaryDisplay.TabIndex = 0;
            SummaryDisplay.Text = "---";
            // 
            // NumberLabel
            // 
            NumberLabel.AutoSize = true;
            NumberLabel.Location = new Point(12, 34);
            NumberLabel.Name = "NumberLabel";
            NumberLabel.Size = new Size(118, 15);
            NumberLabel.TabIndex = 8;
            NumberLabel.Text = "15 numbers selected:";
            // 
            // TotalPositive
            // 
            TotalPositive.AutoSize = true;
            TotalPositive.Location = new Point(12, 133);
            TotalPositive.Name = "TotalPositive";
            TotalPositive.Size = new Size(79, 15);
            TotalPositive.TabIndex = 9;
            TotalPositive.Text = "Total positive:";
            // 
            // TotalZero
            // 
            TotalZero.AutoSize = true;
            TotalZero.Location = new Point(12, 174);
            TotalZero.Name = "TotalZero";
            TotalZero.Size = new Size(60, 15);
            TotalZero.TabIndex = 10;
            TotalZero.Text = "Total zero:";
            // 
            // TotalNegative
            // 
            TotalNegative.AutoSize = true;
            TotalNegative.Location = new Point(12, 216);
            TotalNegative.Name = "TotalNegative";
            TotalNegative.Size = new Size(83, 15);
            TotalNegative.TabIndex = 11;
            TotalNegative.Text = "Total negative:";
            // 
            // PosNum
            // 
            PosNum.AutoSize = true;
            PosNum.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PosNum.ForeColor = Color.Blue;
            PosNum.Location = new Point(122, 116);
            PosNum.Name = "PosNum";
            PosNum.Size = new Size(44, 32);
            PosNum.TabIndex = 12;
            PosNum.Text = "---";
            // 
            // ZeroNum
            // 
            ZeroNum.AutoSize = true;
            ZeroNum.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            ZeroNum.ForeColor = Color.Blue;
            ZeroNum.Location = new Point(122, 160);
            ZeroNum.Name = "ZeroNum";
            ZeroNum.Size = new Size(44, 32);
            ZeroNum.TabIndex = 13;
            ZeroNum.Text = "---";
            // 
            // NegNum
            // 
            NegNum.AutoSize = true;
            NegNum.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            NegNum.ForeColor = Color.Blue;
            NegNum.Location = new Point(122, 202);
            NegNum.Name = "NegNum";
            NegNum.Size = new Size(44, 32);
            NegNum.TabIndex = 14;
            NegNum.Text = "---";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(580, 338);
            Controls.Add(NegNum);
            Controls.Add(ZeroNum);
            Controls.Add(PosNum);
            Controls.Add(TotalNegative);
            Controls.Add(TotalZero);
            Controls.Add(TotalPositive);
            Controls.Add(NumberLabel);
            Controls.Add(SummaryDisplay);
            Name = "Form2";
            Text = "Form2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label SummaryDisplay;
        private Label NumberLabel;
        private Label TotalPositive;
        private Label TotalZero;
        private Label TotalNegative;
        private Label PosNum;
        private Label ZeroNum;
        private Label NegNum;
    }
}
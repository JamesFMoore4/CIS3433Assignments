namespace Proj1
{
    public partial class Form1 : Form
    {

        int range, randvalue;
        List<int> nums = new List<int>();
        Random num = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void EnterButton_Click(object sender, EventArgs e)
        {
            if (RangeTextBox.Text != "")
            {
                try
                {
                    range = Int32.Parse(RangeTextBox.Text);

                    if (range < 0)
                    {
                        range *= -1;
                    }

                    EnterButton.Enabled = false;

                    Timer.Interval = 300;
                    Timer.Start();
                }
                catch (FormatException)
                {
                    RangeTextBox.Clear();
                }
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            randvalue = num.Next(range * -1, range + 1);
            NumberDisplay.Text = randvalue.ToString();
        }

        private void NumberDisplay_Click(object sender, EventArgs e)
        {

            Timer.Stop();

            if (EnterButton.Enabled == false)
            {
                if (nums.Count() < 15)
                {

                    int value = Int32.Parse(NumberDisplay.Text);

                    nums.Add(value);

                    if (nums.Count == 1)
                    {
                        SummaryDisplay.Text = value.ToString();
                    }
                    else
                    {
                        SummaryDisplay.Text += ", " + value.ToString();
                    }
                }
                else
                {
                    MessageBox.Show("You have selected all 15 numbers.", "Program ends");

                    Form2 Summary = new Form2(nums);
                    Summary.ShowDialog();
                }
            }
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            if (EnterButton.Enabled == false && nums.Count() < 15)
            {
                Timer.Start();
            }
        }

        private void SlowButton_Click(object sender, EventArgs e)
        {
            Timer.Interval = 300;
        }

        private void FastButton_Click(object sender, EventArgs e)
        {
            Timer.Interval = 150;
        }
    }
}

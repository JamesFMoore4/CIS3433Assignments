﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            label1.Text = "Welcome to the fruit matching game!\n\nHere you play a simple game by matching three fruit pictures.\n" +
                "You may choose to flip each picture once or twice per second at any time during a game.\nYou will see the total " +
                "games you win and lose displayed on the form title.\nYou may play as many games as you like until you double click " +
                "on its form to close it and return here.\nTo begin a game, double click on this form.";
        }

        private void Form2_DoubleClick(object sender, EventArgs e)
        {
            Form3 fruitMatch = new Form3();
            fruitMatch.ShowDialog();
        }
    }
}

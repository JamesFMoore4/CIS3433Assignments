namespace Proj2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void fruitMatchingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 fruitMatch = new Form2();
            fruitMatch.ShowDialog();
        }

        private void frogCatchingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 frogCatch = new Form4();
            frogCatch.ShowDialog();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj2
{
    public partial class Form4 : Form
    {

        bool gameStarted = false, buttonClicked = true, formClicked = false;
        int score = 0, nextTop, nextLeft;
        Random rand = new Random();

        public Form4()
        {
            InitializeComponent();
            label1.Text = "Win 1 point if you click and hit the frog\nLose 2 points if you clicked but missed\nLose 1 point if you don't click at all";
            label2.Text = "Click the frog to begin....";
            timer1.Interval = 800;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!gameStarted)
            {
                gameStarted = true;
                label1.Visible = label2.Visible = false;
                timer1.Start();
            }
            else
            {
                score++;
                this.Text = "Score = " + score.ToString();
                buttonClicked = true;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!buttonClicked && !formClicked)
            {
                score--;
                this.Text = "Score = " + score.ToString();
            }

            buttonClicked = false;
            formClicked = false;

            nextTop = rand.Next(0, this.ClientSize.Height - button1.Height);
            nextLeft = rand.Next(0, this.ClientSize.Width - button1.Width);
            button1.Top = nextTop;
            button1.Left = nextLeft;
        }

        private void Form4_Click(object sender, EventArgs e)
        {
            formClicked = true;
            score -= 2;
            this.Text = "Score = " + score.ToString();
        }
    }
}

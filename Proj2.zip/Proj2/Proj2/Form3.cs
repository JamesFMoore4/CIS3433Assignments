﻿using Proj2.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj2
{
    public partial class Form3 : Form
    {

        List<System.Drawing.Bitmap> images = new List<System.Drawing.Bitmap>();
        Random rand = new Random();
        int randnum, pbox1Index = 0, pbox2Index = 0, pbox3Index = 0, wins = 0, losses = 0;
        bool btn1Pushed = false, btn2Pushed = false, btn3Pushed = false, timerOn = false;

        public Form3()
        {
            InitializeComponent();
            timer1.Interval = 1000;
            images.Add(Properties.Resources.watermelon);
            images.Add(Properties.Resources.orange);
            images.Add(Properties.Resources.bananas);
            images.Add(Properties.Resources.cherries);
        }

        private void winCheck()
        {
            if (btn1Pushed && btn2Pushed && btn3Pushed)
            {

                if (pbox1Index == pbox2Index && pbox2Index == pbox3Index)
                {
                    MessageBox.Show("You Win");
                    wins++;
                }
                else
                {
                    MessageBox.Show("You Lose");
                    losses++;
                }

                this.Text = "Win: " + wins.ToString() + " Lose: " + losses.ToString();

                timer1.Stop();
                timerOn = false;
                btn1Pushed = btn2Pushed = btn3Pushed = false;
            }
        }

        private void Form3_DoubleClick(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            timer1.Interval = timer1.Interval == 1000 ? 500 : 1000;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            timer1.Start();
            timerOn = true;
            this.Text = "Win: " + wins.ToString() + " Lose: " + losses.ToString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!btn1Pushed)
            {
                randnum = rand.Next(0, 4);
                pictureBox1.Image = images[randnum];
                pbox1Index = randnum;
            }

            if (!btn2Pushed)
            {
                randnum = rand.Next(0, 4);
                pictureBox2.Image = images[randnum];
                pbox2Index = randnum;
            }

            if (!btn3Pushed)
            {
                randnum = rand.Next(0, 4);
                pictureBox3.Image = images[randnum];
                pbox3Index = randnum;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (timerOn)
            {
                btn1Pushed = true;
                winCheck();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (timerOn)
            {
                btn2Pushed = true;
                winCheck();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (timerOn)
            {
                btn3Pushed = true;
                winCheck();
            }
        }
    }
}
